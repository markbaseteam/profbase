---
aliases: 
tags: 
title: Adventory About
---

# Adventory About

## Our Story [[Adventory]]

- Format like an infographic
- This is our origin story
- We grew up with gaming.
- Back then it was embarrassing for some reason to play games, and it was definitely not something you could work with when you got older.
- So we tried the real-life and never fit in. After a very long journey, we landed here.
- Esports market blew up with SC2 in 2010, and we have been following the scene since even before that.
	- We heard about one of the first bar crafts in Lund Sweden while going to the university. I did not end up going but we could see the potential.
- We have heard about a lot of people who want to chase the same dream. But how to be discovered and how to feel empowered?
- We created this platform so everyone can get a chance at creating a career out of their passion for esports and gaming.
- 4 brothers from Stockholm Sweden. Albin, Linus, Oscar, Simon.
	- We have many friends at this point making a living on gaming.
	- It would be fun to join them on their journey and hopefully contribute on the way.
- From streamers to consultants, and journalists with entrepreneurs. Supporting the Swedish scene but also to grow esports globally.
- After being part of the Barstrike initiative in Sweden we could really see the potential of meeting up with friends IRL for drinks and watch games.
- We have seen the energy from various events by Dreamhack and others.
	- We have come a long way for sitting on a couple of benches watching wow 3v3 arena on Dreamhack back in 2009.
- With so many fantastic initiatives all over the world, we want to make everything more accessible.
	- Also nice to encourage people to keep creating from the attention we can bring.
	- Hopefully also contribute to promoting fair and just companies.
