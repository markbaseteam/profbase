---
aliases: 
tags: 
title: Adventory listings
---

# Adventory Listings

Below is a list of the various types of adventures we are keeping on [[Adventory]]!

In addition to this short introduction we also have companion guides.

Each guide describes how to best leverage the different aspects and promote your business.

Products & services are used for products and services released and maintained by a company or individual.

Post stuff here to create hype and buzz for your launch

Venture is used to keep a listing for your company at the same time

News is where you post any updates related to you esports ventures.

News & announcements

Jobs is the place where you can search for partners and employees for your upcoming projects

Events contains all the upcoming events from our beloved partners

Events & competitions

Places are the space for physical locations and education institutions to promote and introduce their ventures to a local audience.

Designed for local businesses that attract local customers.

Our service aims to help you promote your business to new audiences.

As well as providing [[Citations]] and review signals to Google.

Make sure to add business info like number and address.

[[Citations]] from these sources are important.

ven if posts and updates do not give that much value.

The profile info gets indexed by google and adds to your credibility.

Jobs & career

Employer [[branding]]
