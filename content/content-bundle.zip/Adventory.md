---
aliases: 
tags: 
title: Adventory
home: true
---

# Adventory

# Academy

## Guides

Comprehensive guides valuable categories of [[Adventory listings]]

## Premium

Benefits of becoming a paying customer to promote your business on [[Adventory]]

On-site promotion

Paying patrons are given a exclusive code to active the listing promotion functionality on [[Adventory]].

Once promoted your listing will become boosted to the top of any search results on the website.

There is also certain areas on the site dedicated for paid promotions.

Each promotion lasts for 30-days until the patronage is due for renewal.

## Off-site Promotion

In addition to on-site promotion boosted [[Adventory listings]] will be included and featured in various [[Social Media]] content managed by [[Adventory]].

Promotion is also extended to our email newsletters. An email sent out to subscribers showcasing popular and interesting esports ventures.

(Be included as a sponsor to our future podcast and work with us directly on various projects such as case studies and more!)

Patreon

Sections

Validation

Opportunity

Our story (About Us)

This is our origin story

We grew up with gaming.

Background

4 brothers from Stockholm Sweden. Albin, Linus, Oscar, Simon.

We have many friends at this point making a living on gaming.

Would be fun to join them on their journey and hopefully contribute on the way.

After being part of the Barstrike initiative in Sweden we could really see the potential of meeting up with friends IRL for drinks and watch games.

So we tried the real life and never fit in.

After a very long journey we landed here.

Esports market blew up with SC2 in 2010, and we have been following the scene since even before that.

We heard about one of the first bar crafts in Lund Sweden while going to the university.

Did not end up going but we could see the potential.

We have seen the energy from various events by Dreamhack and others.

We have come a long way for sitting on a couple of benches watching wow 3v3 arena on Dreamhack back in 2009.

With so many fantastic initiatives all over the world we want to make everything more accessible.

Also nice to encourage people to keep creating from the attention we can bring.

Hopefully also contribute to promoting fair and just companies.

Privacy

Terms

Homepage

Search box

Featured section

Carousel with

Recent submissions

Popular? blogposts Grid

Explore
