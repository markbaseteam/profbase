---
aliases: 
tags: 
title: Adventory pitch
---

# Adventory Pitch

- Becoming a patron allows your announcements to reach an even larger audience.
- Even beyond the audience directly on [[Adventory]].
- We use [[Social Media]] and other [[Marketing]] channels to spread the gospel of our partners.
- To get more insight into our [[Adventory strategy]] head over to our Patreon page to read more of the reference material.
