---
aliases: 
tags: 
title: Adventory Tutorial
---

# Adventory Tutorial

- ## Tutorial
	- Practical guide on how to use the various functions on
	- Theoretical guide on what benefits we provide and how to achieve access with our platform
- ## [[Adventory]]
	- ### Listings
		- ## Claim listing
			- If your venture already has a listing, you can claim it
			- Create / login to your account
			- Access your listing and fill in the contact form
			- Provide ID (business email) etc, so we can validate ownership
			- Access your listing from the account page, my [[Adventory]] listings
		- ## Add listing
			- Follow the on-page instructions to choose the appropriate type and category.
			- When you click submit, we will do a quick review of the content before publishing your listing.
			- Look for the required fields and make sure they are filled in correctly. (Fill in as much information as possible to aid discovery of your listing)
		- ## Verified
			- We want to build a healthy relationship with wonderful businesses, and we will happily provide insights into how your listing is performing. And also how you may improve your listing over time.
			- Use your business email so we can verify you.
		- ## (Affiliate program)
			- Become and affiliate and earn credits by sharing your profile.
			- When someone creates an account from your profile, you get credits.
			- Credits may be used to boost your listing.
			- You can follow your statistics on the account page.
			- Share your affiliate link with your audience to get help
			- Once a visitor clicks your link and signs up for our newsletter, you will earn a commission as credits on [[Adventory]].
				- (This is the best way to boost additional [[Adventory listings]] you may have in addition to your monthly promotion code)
		- ## Update your listing
			- Please keep in mind that approval might not be instant.
				- If you are, making changes of a time sensitive nature.
			- Remember to send your edit for approval ahead of time.
		- ## Manage Your listings
			- Designed for local businesses that attract local customers.
			- Our service aims to help you promote your business to new audiences, as well as providing [[Citations]] and review signals to Google.
		- ## Photos
			- Listing photos to drive engagement
				- Feature photos from the venue taken by visitors and staff.
				- Potential visitors can see how the venue looks from inside and get comfortable with the new space.
					- It’s also easier to recognize the entrance when they finally arrive in the area.
				- [[Adventory listings]] with photos get 42% more map direction requests, 35% more clicks to the business website compared to [[Adventory listings]] without photos.
		- ## Categories
			- Place the listing within the right category
			- Make sure to place your business within the right category, else you may risk losing customers that prefer to filter options then searching ex.
			- Try to be as specific as possible with the categories, but sometimes it's necessary to pick a broader one.
				- (Contact us to add a missing category)
			- Specify if you are not welcoming guests at your location.
				- For instance, if you are selling services at various locations.
				- Provides a service area instead of a specific location.
	- ## Account
		- Bookmarking
			- A powerful way to save your favorite ventures for the future is to save bookmarks.
			- The perfect way to plan your upcoming trip by saving interesting locations in advance. Add online services for evaluation before committing to a new provider for your own venture.
		- Account creation
			- Click on the Account button in the top right corner to access the login prompt
			- Login with your [[Patreon]] account to access the account page.
				- We use Patreon for all authentications to keep the service nice and welcoming while avoiding the worst trolls.
			- Login to manage your [[Adventory listings]], access bookmarks, comment on guides and review other [[Adventory listings]].
		- (Messaging)
		- ## [[Reviews]]
			- If you have first-hand experience with one of the [[Adventory listings]] we encourage you to share your thoughts.
			- Try to be as comprehensive as possible and focus on sharing something of value to others.
			- [[Reviews]] are going to be moderated to keep a high level of discussion.
		- ## Login
			- We use Google authentication for account management.
			- Safe and validated method to provide a valuable service for everyone.
			- Make sure to always have 2-way authentication enable on your Google account.
- **

Account information

## Account

### Account Creation

1. Click on the Account button in the top right corner to access the login prompt

2. Log in with your Patreon account to access the account page. We use Patreon for all authentications to keep the service nice and welcoming while avoiding the worst trolls.

3. Log in to manage your listings, access bookmarks, comment on guides and review other listings.

### Bookmarking

1. A powerful way to save your favorite ventures for the future is to save bookmarks.

2. The perfect way to plan your upcoming trip by saving interesting locations in advance. Add online services for evaluation before committing to a new provider for your own venture.

## [[Analytics]]

How to use the stats from your listing.

## Listings

### Add Listing

1. Go to your account my listings and “add listing”

2. Follow the on-page instructions to choose the appropriate type and category.

3. When you click submit we will do a quick review of the content before publishing your listing.

4. Look for the required fields and make sure they are filled in correctly. (Fill in a much information as possible to aid discovery of your listing)

### Claim Listing

1. If your venture already has a listing you can claim it

2. Create / login to your account

3. Access your listing and fill in the contact form

4. Provide ID (business email) etc so we can validate ownership

5. Access your listing from the account page, my listings

### Listing Types

Below is a list of the various types of adventures we are keeping on [[Adventory]]! In addition to this short introduction we also have companion guide to each type describing how to best leverage the different aspect and promote your business.

1. Product is used for products and services released and maintained by a company or individual. Post stuff here to create hype and buzz for your launch

2. Venture is used to keep a listing for your company at the same time

3. News is where you post any updates related to you esports ventures.

4. Jobs is the place where you can search for partners and employees for your upcoming projects

5. Events contains all the upcoming events from our beloved partners

6. Places is the space for physical locations and education institutions to promote and introduce their ventures to a local audience.

### Listing Optimization

1. 700 words

2. Make sure to fill in as much information as possible

1. Important to include images to attract visitors

2. Be sure to answer any reviews

3. Craft a short and to the point text presentation

4. Include links to your social media

5. Make your profile relatable and show your face

6. Keep listing updated

7. What can you bring to the table and what makes your business special?

1. Make sure to include your physical address, telephone number and open hours if you are a local venture.

4. Keep you listing updated for people visiting in the future.

3. Contact information should also be updated.

4. Keep in mind our review process, we try to be fast but post your announcements a few days ahead of the event.

### Manage Your Listings

Designed for local businesses that attract local customers. Our service aims to help you promote your business to new audiences, as well as providing [[citations]] and review signals to Google.

### Add Essential Information to Get Found

Adds your company info to google search and google maps. Add your hours of operation, including special holiday schedules, and also include the website URL. Get directions to the location right from where the spot you are standing on. Phone number is also available and since you are already on the phone it’s easy to phone the place to ask any additional questions.

People can also search for a specific activity to explore and the search results will show well set up business in the area. Important to setup you're listing with the correct information. This is not the place to be funny (at least not too funny).

### Use Listing Photos to Drive Engagement

Feature photos from the venue taken by visitors and staff. Potential visitors can see how the venue looks from inside and get comfortable with the new space. It’s also easier to recognize the entrance when they finally arrive in the area.

Listings with photos get 42% more map direction requests, 35% more clicks to the business website compared to listings without photos.

### Place the Listing Within the Right Category

Make sure to place your business within the right category, else you may risk losing customers that prefer to filter options then searching ex.

Try to be as specific as possible with the categories, but sometimes it's necessary to pick a broader one. (Contact us to add a missing category). Specify if you are not welcoming guests at your location. For instance if you are selling services at various locations. Provides a service area instead of a specific location.

### Verify the Listing to Build Trust

Verify your listing by proving that you are representing the business, and become a member to fill in extended information. Important to hand over correct credentials to avoid being banned from the service.

We want to build a healthy relationship with wonderful businesses and we will happily provide insights into how you’re listing is performing. And also how you may improve your listing over time.

## The Adventory Advantage

Becoming a patron allows your announcements to reach an even larger audience, even beyond the audience directly on adventory.gg.

We use social media and other marketing channels to spread the gospel of our partners. To get more insight into our strategy head over to our Patreon page to read more of the reference material.

## Promotion (Patreon)

As firm believers in paid [[advertising]] as the best way to boost your reach to even greater heights we offer our partners a way to promote their ventures.

In addition to promotion we also offer additional reference material on our Patreon-page. Giving you advanced insights into how we plan and execute on our strategy to spread the message of esports to the world.

Finally Patreon unlocks the ability to join our community and share tactics with passionate esports entrepreneurs, as well as asking personal questions to be included in our ongoing effort of creating value by sharing knowledge.

### How to Promote Your Listing

1. Our patrons will receive a code each month to promote their listings.

2. A code will be sent to current patrons at the date of renewal.

3. The code is valid for 1 promotion to boost your listing for 30-days.

4. The code may only be used once, be sure not to share your account.

### What Does the Promotion Do

1. The promotion sends your listing to the top of all the search results on Adventory.gg.

2. Promotion will also include your listing in our paid [[advertising]] campaigns.

3. Allows the listing to be featured in our email communication.

### On-site Promotion

1. Paying patrons are given an exclusive code to active the listing promotion functionality on Adventory.gg.

2. Once promoted your listing will become boosted to the top of any search results on the website. There is also certain areas on the site dedicated for paid promotions.

3. Each promotion lasts for 30-days until the patronage is due for renewal.

### Off-site Promotion

1. In addition to on-site promotion boosted listings will be included and featured in various social media content managed by Adventory.

2. Promotion is also extended to our email newsletters. An email sent out to subscribers showcasing popular and interesting esports ventures.

3. (Be included as a sponsor to our future podcast and work with us directly on various projects such as case studies and more!)

## Reviews

How to write reviews and how it works on Adventory.gg.

In this guide to handling online reviews in the esports industry we will answer the following questions. Be sure to follow along to make the most out of audience feedback here on Adventory and everywhere else where people can leave reviews on your offering.

**
